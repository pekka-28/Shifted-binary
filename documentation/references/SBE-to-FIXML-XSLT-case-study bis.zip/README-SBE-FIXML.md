<!-- README-SBE-FIXML.md: schema-driven SBE-to-FIXML XSLT 1.0 demonstration using shifted-binary template dispatch. -->
# SBE to FIXML using generated XSLT

This example takes a SOFH-framed SBE `NewOrderSingle` message embedded as shifted binary in `<message><binary>…</binary></message>` and produces its FIXML 5.0 SP2 business representation. The order instructs a trading venue or broker to buy 7 units of `GEM4` at a limit price of 99.610.

## Files

| File | Role |
|---|---|
| `NewOrderSingle.sbe.xml` | Encoding schema based on the FIX SBE 1.0 §9.1 example; definitions retained and descriptive attributes abbreviated |
| `generate-FIXML-decoder.xslt` | XSLT 1.0 meta-stylesheet: reads the SBE schema and emits a decoder stylesheet |
| `NewOrderSingle-to-FIXML.xslt` | Generated XSLT 1.0 decoder and FIXML projection |
| `Shifted binary.xslt` | User-supplied canonical shifted-binary mapping, imported by the generated decoder |
| `NewOrderSingle-shifted-message.xml` | 68 B case-study SOFH/SBE wire message represented as U+E100–U+E1FF characters |
| `NewOrderSingle-expected.fixml.xml` | Expected decoded FIXML document |

Generate with an XSLT 1.0 processor, applying `generate-FIXML-decoder.xslt` to `NewOrderSingle.sbe.xml`. Apply the resulting stylesheet to `NewOrderSingle-shifted-message.xml`. Keep the generated stylesheet beside `Shifted binary.xslt` to resolve its import.

## Shifted-binary template dispatch

Both stylesheets exploit XPath's existing string model:

- The **generator** dispatches on a schema match predicate for a little-endian `NewOrderSingle` template and uses the imported shifted alphabet to **pack** the schema's `blockLength`, `templateId`, `schemaId` and `version` as literal shifted characters.
- The **generated decoder** has a template with `match="message[substring(binary, 5, 10) = '…']"`, where the ellipsis is the actual 10-character canonical shifted sequence for the SOFH encoding and SBE message header. No header unpacking is needed to select the template.
- The decoder then uses `substring()` for direct field slicing and `string-length()` for framing length checks. It decodes individual numeric fields only when their values are needed, using reusable decoding templates.
- A fallback `match="message"` template terminates with an error for unknown encodings, message layouts or noncanonical headers. The input contract requires canonical U+E100–U+E1FF shifted characters, not mixed-mode shifted text. This strengthens the previous decoder's input contract, which performed a preliminary `translate()` on mixed input.

The binary fields, offsets, widths, underlying types and decimal exponents are obtained from the SBE schema. The FIXML output mapping (for example, SBE `ClOrdID` to FIXML `Order/@ID`) is deliberately defined in the generator for this specific `NewOrderSingle` profile; it cannot be derived solely from the SBE schema. The implementation supports the flat fixed-length template used in the case study, not arbitrary SBE messages with repeating groups or variable-length fields.

**Date precision:** The timestamp is presented to the nearest millisecond. This is sufficient for the supplied example but would discard sub-millisecond precision in other inputs. The illustrative decoder's date conversion supports nonnegative Unix timestamps.

**Source discrepancy:** The preceding case-study wire message uses SBE `schemaId=100` (`64 00`), consistent with the published example schema's `id="100"`. The published SBE standard's example *wire message*, however, carries `schemaId=91` (`5B 00`). The byte sequence in this package follows the user's case-study document; it is not byte-for-byte identical to the standard's wire example. The timestamp bytes also follow the case-study document. In particular, do not describe the packaged wire message as an unmodified reproduction of the standard's wire example.

**Validation:** The template predicate recognises the SOFH encoding and SBE block length/template ID/schema ID/version together. Inside the matched template, the decoder checks the SOFH length and shifted-binary alphabet. An unknown header, wrong length or invalid character terminates the transform. The supplied files were tested with `lxml`/libxslt, including schema-ID regeneration and rejection of mutated header bytes.

## References

- FIX Trading Community, [Simple Binary Encoding (SBE), version 1.0 with errata, §9.1](https://www.fixtrading.org/wp-content/uploads/download-manager-files/Simple_Binary_Encoding_V1.0_with_Errata_November_2020.pdf).
- FIX Trading Community, [SBE example message schema](https://github.com/FIXTradingCommunity/fix-simple-binary-encoding/blob/master/v1-0-STANDARD/doc/07Examples.md).
- FIX Trading Community, [FIXML Technical Standard v1.1](https://www.fixtrading.org/wp-content/uploads/download-manager-files/FIXML-Technical-Standard-V1.1.pdf).
