<?xml version="1.0" encoding="UTF-8"?>
<!-- generate-FIXML-decoder.xslt: generate a byte decoder and FIXML projection from an SBE schema. -->
<xsl:stylesheet version="1.0"
  xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
  xmlns:gen="urn:generate-xslt"
  xmlns:sbe="http://fixprotocol.io/2016/sbe"
  exclude-result-prefixes="sbe gen">
  <xsl:import href="Shifted%20binary.xslt"/>
  <xsl:namespace-alias stylesheet-prefix="gen" result-prefix="xsl"/>
  <xsl:output method="xml" indent="yes" encoding="UTF-8"/>
  <xsl:strip-space elements="*"/>

  <!-- The SBE schema determines all binary offsets, widths, and types.
       The FIXML destination mapping below is a separate FIX NewOrderSingle profile. -->
  <!-- A schema template is itself selected by a declarative XPath match predicate. -->
  <xsl:template match="/sbe:messageSchema[@byteOrder='littleEndian'][sbe:message[@id='99' and @semanticType='D']]">
    <xsl:if test="@byteOrder != 'littleEndian' or not(sbe:message[@id='99' and @semanticType='D'])">
      <xsl:message terminate="yes">This example generator requires a little-endian NewOrderSingle (template 99).</xsl:message>
    </xsl:if>
    <xsl:variable name="order" select="sbe:message[@id='99']"/>
    <xsl:variable name="types" select="types"/>
    <xsl:if test="count($order/field)!=9 or count($order/field[@id='11' or @id='1' or @id='55' or @id='54' or @id='60' or @id='38' or @id='40' or @id='44' or @id='99'])!=9">
      <xsl:message terminate="yes">FIXML projection expects the nine published order fields.</xsl:message>
    </xsl:if>
    <gen:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform">
      <gen:import href="Shifted%20binary.xslt"/>
      <gen:output method="xml" indent="yes" encoding="UTF-8"/>
      <!-- The generator emits a literal 10-byte shifted-binary signature:
           SOFH encoding (2 B), SBE block length/template/schema/version (8 B).
           This match pattern dispatches without running a numeric decoder. -->
      <gen:template priority="2">
        <xsl:attribute name="match"><xsl:text>message[substring(binary, 5, 10) = '</xsl:text><xsl:text>&#xE1EB;&#xE150;</xsl:text><xsl:call-template name="shifted-u16"><xsl:with-param name="value" select="number($order/@blockLength)"/></xsl:call-template><xsl:call-template name="shifted-u16"><xsl:with-param name="value" select="number($order/@id)"/></xsl:call-template><xsl:call-template name="shifted-u16"><xsl:with-param name="value" select="number(@id)"/></xsl:call-template><xsl:call-template name="shifted-u16"><xsl:with-param name="value" select="0"/></xsl:call-template><xsl:text>']</xsl:text></xsl:attribute>
        <!-- Canonical shifted byte values require no translation before slicing. -->
        <gen:variable name="bytes" select="string(binary)"/>
        <gen:if test="translate($bytes, string($canonicalShifted), '') != ''">
          <gen:message terminate="yes">Non-binary character in message.</gen:message>
        </gen:if>
        <gen:variable name="length"><gen:call-template name="unsigned"><gen:with-param name="bytes" select="substring($bytes, 1, 4)"/><gen:with-param name="endian" select="'big'"/></gen:call-template></gen:variable>
        <gen:if test="string-length($bytes) != number($length)">
          <gen:message terminate="yes">SOFH message length mismatch.</gen:message>
        </gen:if>
        <xsl:for-each select="$order/field">
          <xsl:variable name="typeName" select="@type"/>
          <xsl:variable name="type" select="$types/*[@name=$typeName]"/>
          <xsl:variable name="source" select="($type/self::composite/type[@name='mantissa'] | $type/self::type)[1]"/>
          <xsl:variable name="kind" select="string(($source/@primitiveType | $types/type[@name=$type/@encodingType]/@primitiveType)[1])"/>
          <xsl:variable name="enumEncoding" select="$types/type[@name=$type/@encodingType]/@primitiveType"/>
          <xsl:variable name="width">
            <xsl:choose>
              <xsl:when test="$source/@length"><xsl:value-of select="$source/@length"/></xsl:when>
              <xsl:when test="$source/@primitiveType='uint64' or $source/@primitiveType='int64'">8</xsl:when>
              <xsl:when test="$source/@primitiveType='uint32' or $source/@primitiveType='int32'">4</xsl:when>
              <xsl:when test="$source/@primitiveType='uint16' or $source/@primitiveType='int16'">2</xsl:when>
              <xsl:when test="$source/@primitiveType='char' or $enumEncoding='char'">1</xsl:when>
              <xsl:otherwise><xsl:message terminate="yes">Unsupported field encoding.</xsl:message></xsl:otherwise>
            </xsl:choose>
          </xsl:variable>
          <xsl:if test="not($type) or not(@offset) or not(string($width))"><xsl:message terminate="yes">Missing type or offset.</xsl:message></xsl:if>
          <gen:variable name="v{@name}">
            <gen:call-template name="decode">
              <gen:with-param name="raw" select="substring($bytes, {15 + number(@offset)}, {number($width)})"/>
              <gen:with-param name="kind" select="'{($source/@primitiveType | $enumEncoding)[1]}'"/>
              <gen:with-param name="scale">
                <xsl:attribute name="select"><xsl:choose><xsl:when test="$type/type[@name='exponent']"><xsl:value-of select="$type/type[@name='exponent']"/></xsl:when><xsl:otherwise>0</xsl:otherwise></xsl:choose></xsl:attribute>
              </gen:with-param>
              <gen:with-param name="optional" select="'{string($source/@presence)}'"/>
              <gen:with-param name="timestamp" select="'{string(@semanticType='UTCTimestamp' or $source/@semanticType='UTCTimestamp')}'"/>
            </gen:call-template>
          </gen:variable>
        </xsl:for-each>
        <gen:element name="FIXML" namespace="http://www.fixprotocol.org/FIXML-5-0-SP2">
          <gen:attribute name="v">FIX.5.0SP2</gen:attribute>
          <gen:element name="Order" namespace="http://www.fixprotocol.org/FIXML-5-0-SP2">
            <gen:attribute name="ID"><gen:value-of select="$vClOrdID"/></gen:attribute>
            <gen:attribute name="Acct"><gen:value-of select="$vAccount"/></gen:attribute>
            <gen:attribute name="Side"><gen:value-of select="$vSide"/></gen:attribute>
            <gen:attribute name="TxnTm"><gen:value-of select="$vTransactTime"/></gen:attribute>
            <gen:attribute name="Typ"><gen:value-of select="$vOrdType"/></gen:attribute>
            <gen:if test="string($vPrice)!=''"><gen:attribute name="Px"><gen:value-of select="$vPrice"/></gen:attribute></gen:if>
            <gen:if test="string($vStopPx)!=''"><gen:attribute name="StopPx"><gen:value-of select="$vStopPx"/></gen:attribute></gen:if>
            <gen:element name="Instrmt" namespace="http://www.fixprotocol.org/FIXML-5-0-SP2">
              <gen:attribute name="Sym"><gen:value-of select="$vSymbol"/></gen:attribute>
            </gen:element>
            <gen:element name="OrdQty" namespace="http://www.fixprotocol.org/FIXML-5-0-SP2">
              <gen:attribute name="Qty"><gen:value-of select="$vOrderQty"/></gen:attribute>
            </gen:element>
          </gen:element>
        </gen:element>
      </gen:template>
      <!-- Unrecognised binary messages must not fall through silently. -->
      <gen:template match="message" priority="-1">
        <gen:message terminate="yes">Unrecognised SBE header or noncanonical shifted binary.</gen:message>
      </gen:template>

      <!-- Canonical shifted byte to 0..255 using the supplied mapping alphabet. -->
      <gen:template name="byte-value">
        <gen:param name="char"/>
        <gen:value-of select="string-length(substring-before(string($canonicalShifted), $char))"/>
      </gen:template>
      <gen:template name="unsigned">
        <gen:param name="bytes"/><gen:param name="endian" select="'little'"/><gen:param name="result" select="0"/>
        <gen:choose>
          <gen:when test="string-length($bytes)=0"><gen:value-of select="$result"/></gen:when>
          <gen:otherwise>
            <gen:variable name="c"><gen:choose><gen:when test="$endian='little'"><gen:value-of select="substring($bytes,string-length($bytes),1)"/></gen:when><gen:otherwise><gen:value-of select="substring($bytes,1,1)"/></gen:otherwise></gen:choose></gen:variable>
            <gen:variable name="b"><gen:call-template name="byte-value"><gen:with-param name="char" select="string($c)"/></gen:call-template></gen:variable>
            <gen:call-template name="unsigned">
              <gen:with-param name="bytes"><gen:choose><gen:when test="$endian='little'"><gen:value-of select="substring($bytes,1,string-length($bytes)-1)"/></gen:when><gen:otherwise><gen:value-of select="substring($bytes,2)"/></gen:otherwise></gen:choose></gen:with-param>
              <gen:with-param name="endian" select="$endian"/>
              <gen:with-param name="result" select="$result*256+number($b)"/>
            </gen:call-template>
          </gen:otherwise>
        </gen:choose>
      </gen:template>
      <gen:template name="decode">
        <gen:param name="raw"/><gen:param name="kind"/><gen:param name="scale" select="0"/><gen:param name="optional"/><gen:param name="timestamp"/>
        <gen:choose>
          <gen:when test="$kind='char'">
            <gen:variable name="unshifted" select="translate($raw, string($canonicalShifted), string($shiftedText))"/>
            <gen:value-of select="substring-before(concat($unshifted,'&#xE100;'),'&#xE100;')"/>
          </gen:when>
          <gen:when test="$optional='optional' and $kind='int64' and $raw='&#xE100;&#xE100;&#xE100;&#xE100;&#xE100;&#xE100;&#xE100;&#xE180;'"/>
          <gen:when test="$timestamp='true'">
            <gen:variable name="ns"><gen:call-template name="unsigned"><gen:with-param name="bytes" select="$raw"/></gen:call-template></gen:variable>
            <gen:call-template name="format-timestamp"><gen:with-param name="milliseconds" select="round(number($ns) div 1000000)"/></gen:call-template>
          </gen:when>
          <gen:otherwise>
            <gen:variable name="u"><gen:call-template name="unsigned"><gen:with-param name="bytes" select="$raw"/></gen:call-template></gen:variable>
            <gen:variable name="last"><gen:call-template name="byte-value"><gen:with-param name="char" select="substring($raw,string-length($raw),1)"/></gen:call-template></gen:variable>
            <gen:variable name="value">
              <gen:choose>
                <gen:when test="starts-with($kind,'int') and number($last) &gt;= 128"><gen:value-of select="number($u) - (number(string-length($raw)=8)*18446744073709551616 + number(string-length($raw)=4)*4294967296 + number(string-length($raw)=2)*65536 + number(string-length($raw)=1)*256)"/></gen:when>
                <gen:otherwise><gen:value-of select="number($u)"/></gen:otherwise>
              </gen:choose>
            </gen:variable>
            <gen:choose>
              <gen:when test="number($scale)=-3"><gen:value-of select="format-number(number($value) div 1000, '0.000')"/></gen:when>
              <gen:when test="number($scale)=0"><gen:value-of select="format-number(number($value), '0')"/></gen:when>
              <gen:otherwise><gen:message terminate="yes">Unsupported decimal exponent.</gen:message></gen:otherwise>
            </gen:choose>
          </gen:otherwise>
        </gen:choose>
      </gen:template>
      <!-- Date algorithm for nonnegative Unix milliseconds; years/months handled in XSLT 1.0. -->
      <gen:template name="format-timestamp">
        <gen:param name="milliseconds"/>
        <gen:variable name="days" select="floor($milliseconds div 86400000)"/>
        <gen:variable name="dayMillis" select="$milliseconds mod 86400000"/>
        <gen:variable name="ym"><gen:call-template name="year-month-day"><gen:with-param name="days" select="$days"/></gen:call-template></gen:variable>
        <gen:value-of select="concat(string($ym),'T',format-number(floor($dayMillis div 3600000),'00'),':',format-number(floor($dayMillis mod 3600000 div 60000),'00'),':',format-number(floor($dayMillis mod 60000 div 1000),'00'),'.',format-number($dayMillis mod 1000,'000'),'Z')"/>
      </gen:template>
      <gen:template name="year-month-day">
        <gen:param name="days"/><gen:param name="year" select="1970"/>
        <gen:variable name="leap" select="($year mod 4 = 0 and $year mod 100 != 0) or $year mod 400 = 0"/>
        <gen:variable name="yearDays" select="365 + number($leap)"/>
        <gen:choose>
          <gen:when test="$days &gt;= $yearDays"><gen:call-template name="year-month-day"><gen:with-param name="days" select="$days - $yearDays"/><gen:with-param name="year" select="$year+1"/></gen:call-template></gen:when>
          <gen:otherwise><gen:call-template name="month-day"><gen:with-param name="days" select="$days"/><gen:with-param name="year" select="$year"/><gen:with-param name="leap" select="$leap"/></gen:call-template></gen:otherwise>
        </gen:choose>
      </gen:template>
      <gen:template name="month-day">
        <gen:param name="days"/><gen:param name="year"/><gen:param name="leap"/><gen:param name="month" select="1"/>
        <gen:variable name="monthDays">
          <gen:choose><gen:when test="$month=2"><gen:value-of select="28+number($leap)"/></gen:when>
            <gen:when test="$month=4 or $month=6 or $month=9 or $month=11">30</gen:when>
            <gen:otherwise>31</gen:otherwise></gen:choose>
        </gen:variable>
        <gen:choose>
          <gen:when test="$days &gt;= number($monthDays)"><gen:call-template name="month-day"><gen:with-param name="days" select="$days - number($monthDays)"/><gen:with-param name="year" select="$year"/><gen:with-param name="leap" select="$leap"/><gen:with-param name="month" select="$month+1"/></gen:call-template></gen:when>
          <gen:otherwise><gen:value-of select="concat(format-number($year,'0000'),'-',format-number($month,'00'),'-',format-number($days+1,'00'))"/></gen:otherwise>
        </gen:choose>
      </gen:template>
    </gen:stylesheet>
  </xsl:template>

  <!-- Pack a schema-defined uint16 into two literal shifted characters;
       the value is interpreted as little-endian in the SBE message header. -->
  <xsl:template name="shifted-u16">
    <xsl:param name="value"/>
    <xsl:if test="$value &lt; 0 or $value &gt; 65535 or $value != floor($value)">
      <xsl:message terminate="yes">Header value out of uint16 range.</xsl:message>
    </xsl:if>
    <xsl:value-of select="substring(string($canonicalShifted), ($value mod 256) + 1, 1)"/>
    <xsl:value-of select="substring(string($canonicalShifted), floor($value div 256) + 1, 1)"/>
  </xsl:template>
  <xsl:template match="sbe:messageSchema" priority="-1">
    <xsl:message terminate="yes">Unsupported SBE schema or message template.</xsl:message>
  </xsl:template>
</xsl:stylesheet>
